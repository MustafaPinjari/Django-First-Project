from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def analyzer(request):
    djtext = request.GET.get('text', 'default')
    spaceremover = request.GET.get('spaceremover', 'off')
    countlength = request.GET.get('countlength', 'off')
    uppercase = request.GET.get('uppercase', 'off')
    lowercase = request.GET.get('lowercase', 'off')
    removepunctuation = request.GET.get('removepunctuation', 'off')
    titlecase = request.GET.get('titlecase', 'off')
    reverse = request.GET.get('reverse', 'off')

    original_text = djtext  # Store the original text
    analyzed_text = djtext  # Initialize analyzed_text with the original text
    transformations = []  # Initialize a list to store the transformations applied

    # Remove Space
    if spaceremover == "on":
        analyzed_text = analyzed_text.replace(" ", "")
        transformations.append('Remove Space')

    # Count Length
    if countlength == "on":
        length = len(analyzed_text)
        transformations.append(f'Count Length: {length}')

    # Upper Case
    if uppercase == "on":
        analyzed_text = analyzed_text.upper()
        transformations.append('Converted to upper case')

    # Lower Case
    if lowercase == "on":
        analyzed_text = analyzed_text.lower()
        transformations.append('Converted to lower case')

    # Remove Punctuation
    if removepunctuation == "on":
        import string
        analyzed_text = analyzed_text.translate(str.maketrans("", "", string.punctuation))
        transformations.append('Removed Punctuation')

    # Title Case
    if titlecase == "on":
        analyzed_text = analyzed_text.title()
        transformations.append('Converted to title case')

    # Reverse String
    if reverse == "on":
        analyzed_text = analyzed_text[::-1]
        transformations.append('Reversed String')

    params = {
        'original_text': original_text,
        'transformations': transformations,
        'analyzed_text': analyzed_text,
    }

    return render(request, 'analyzer.html', params)
